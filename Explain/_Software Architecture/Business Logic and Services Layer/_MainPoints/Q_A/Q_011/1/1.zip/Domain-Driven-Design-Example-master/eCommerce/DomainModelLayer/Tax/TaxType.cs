﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eCommerce.DomainModelLayer.Tax
{
    public enum TaxType
    {
        Business,
        Customer
    }
}
