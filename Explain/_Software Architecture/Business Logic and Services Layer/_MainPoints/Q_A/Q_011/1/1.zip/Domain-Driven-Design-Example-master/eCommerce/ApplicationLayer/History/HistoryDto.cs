﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eCommerce.ApplicationLayer.History
{
    public class HistoryDto
    {
        public List<EventDto> Events { get; set; }
    }
}
