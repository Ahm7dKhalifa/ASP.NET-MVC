﻿using System;
using System.Configuration;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace DataAccessHandler.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("============== Using SQL Helper =======================\n\n\n");
            UsingSqlHelper();
            Console.WriteLine("\n\nPress any key to exist...");
            Console.ReadKey();
        }

        private static void UsingSqlHelper()
        {
            var dbManager = new SqlHelper(ConfigurationManager.ConnectionStrings["DBConnection"].ToString());

            var user = new User
            {
                FirstName = "First",
                LastName = "Last",
                Dob = DateTime.Now.AddDays(-3000),
                IsActive = true
            };

            var parameters = new List<SqlParameter>();
            parameters.Add(dbManager.CreateParameter("@FirstName", 50, user.FirstName, DbType.String));
            parameters.Add(dbManager.CreateParameter("@LastName", user.LastName, DbType.String));
            parameters.Add(dbManager.CreateParameter("@Dob", user.Dob, DbType.DateTime));
            parameters.Add(dbManager.CreateParameter("@IsActive", 50, user.IsActive, DbType.Boolean));

            //INSERT
            int lastId = 0;
            dbManager.Insert("DAH_User_Insert", CommandType.StoredProcedure, parameters.ToArray(), out lastId);
            Console.WriteLine("\nINSERTED ID: " + lastId);

            //DATATABLE
            var dataTable = dbManager.GetDataTable("DAH_User_GetAll", CommandType.StoredProcedure);
            Console.WriteLine("\nTOTAL ROWS IN TABLE: " + dataTable.Rows.Count);

            //DATAREADER
            SqlConnection connection = null;
            var dataReader = dbManager.GetDataReader("DAH_User_GetAll", CommandType.StoredProcedure, null, out connection);
            try
            {
                user = new User();
                while (dataReader.Read())
                {
                    user.FirstName = dataReader["FirstName"].ToString();
                    user.LastName = dataReader["LastName"].ToString();
                }

                Console.WriteLine(string.Format("\nDATA READER VALUES FirstName{0}: LastName:{1}", user.FirstName, user.LastName));
            }
            catch (Exception)
            {

            }
            finally
            {
                dataReader.Close();
                dbManager.CloseConnection(connection);
            }

            //SCALAR
            object scalar = dbManager.GetScalarValue("DAH_User_Scalar", CommandType.StoredProcedure);
            Console.WriteLine("\nSCALAR VALUE: " + scalar.ToString());

            //UPDATE
            user = new User
            {
                Id = lastId,
                FirstName = "First1",
                LastName = "Last1",
                Dob = DateTime.Now.AddDays(-5000)
            };

            parameters = new List<SqlParameter>();
            parameters.Add(dbManager.CreateParameter("@Id", user.Id, DbType.Int32));
            parameters.Add(dbManager.CreateParameter("@FirstName", 50, user.FirstName, DbType.String));
            parameters.Add(dbManager.CreateParameter("@LastName", user.LastName, DbType.String));
            parameters.Add(dbManager.CreateParameter("@Dob", user.Dob, DbType.DateTime));
            dbManager.Update("DAH_User_Update", CommandType.StoredProcedure, parameters.ToArray());

            //DATATABLE
            dataTable = dbManager.GetDataTable("DAH_User_GetAll", CommandType.StoredProcedure);
            Console.WriteLine(string.Format("\nUPADTED VALUES FirstName{0}: LastName:{1}", dataTable.Rows[0]["FirstName"].ToString(), dataTable.Rows[0]["LastName"].ToString()));

            //DELETE
            parameters = new List<SqlParameter>();
            parameters.Add(dbManager.CreateParameter("@Id", user.Id, DbType.Int32));
            dbManager.Delete("DAH_User_Delete", CommandType.StoredProcedure, parameters.ToArray());

            //DATATABLE
            dataTable = dbManager.GetDataTable("DAH_User_GetAll", CommandType.StoredProcedure);
            Console.WriteLine("\nTOTAL ROWS IN TABLE: " + dataTable.Rows.Count);
        }
    }
}
