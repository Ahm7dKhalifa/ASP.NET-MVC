﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Core.Common.Contracts;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Core.Common.Tests
{
    [TestClass]
    public class ObjectBaseTests
    {

    }
}
