﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.thecoderlife.example.productcatalog.model
{
    public enum DimensionUnit
    {
        Inches = 1,
        Meters,
        Centimeters
    }

    public class Dimension
    {
        private float lenght;
        private float height;
        private float depth;
        private DimensionUnit unit;

        public Dimension(float lenght, float height, float depth, DimensionUnit unit)
        {
            if (lenght <= 0)
                throw new Exception("Invalid lenght! Please, provide a valid value.");

            if (height <= 0)
                throw new Exception("Invalid height! Please, provide a valid value.");

            if (depth <= 0)
                throw new Exception("Invalid depth! Please, provide a valid value.");

            this.lenght = lenght;
            this.height = height;
            this.depth = depth;
            this.unit = unit;
        }

        public float GetLenght()
        {
            return this.lenght;
        }

        public float GetHeight()
        {
            return this.height;
        }

        public float GetDepth()
        {
            return this.depth;
        }

        public DimensionUnit GetUnit()
        {
            return this.unit;
        }
    }
}
