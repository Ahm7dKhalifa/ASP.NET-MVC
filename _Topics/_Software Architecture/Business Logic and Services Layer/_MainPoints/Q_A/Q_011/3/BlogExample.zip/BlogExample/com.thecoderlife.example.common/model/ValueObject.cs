﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace com.thecoderlife.example.common.model
{
    public abstract class ValueObject
    {
        public override bool Equals(object obj)
        {
            if (obj == null || !obj.GetType().Equals(this.GetType()))
                return false;

            object thisValueAux = null;
            object objValeuAux = null;
            bool result = false;

            foreach (FieldInfo field in this.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic))
            {
                thisValueAux = field.GetValue(this);
                objValeuAux = obj.GetType().GetField(field.Name, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(obj);

                if (thisValueAux != null && objValeuAux != null)
                {
                    result = thisValueAux.Equals(objValeuAux);
                }
                else if (thisValueAux == null && objValeuAux == null)
                {
                    result = true;
                }
                else if ((thisValueAux == null && objValeuAux != null) ||
                            (thisValueAux != null && objValeuAux == null)
                        )
                {
                    result = false;
                }

                if (!result)
                    break;
            }

            return result;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}
