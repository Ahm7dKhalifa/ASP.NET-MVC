﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.thecoderlife.example.common.respository
{
    public class ObjectRepository
    {
        private static ObjectRepository instance;
        private IDictionary<Guid, object> repository;

        private ObjectRepository() 
        {
            repository = new Dictionary<Guid, object>();
        }

        public static ObjectRepository GetInstance()
        {
            if (instance == null)
                instance = new ObjectRepository();

            return instance;
        }

        public void Persist(Guid id, object obj)
        {
            if ( ! this.repository.ContainsKey(id))
            {
                this.repository.Add(id, obj);
            }
        }

        public T Get<T>(Guid id)
        {
            T obj = default(T);

            if (this.repository.ContainsKey(id))
            {
                obj = (T) this.repository[id];
            }

            return obj;
        }

        public IList<T> GetAllOf<T>()
        {
            IList<T> myList = new List<T>();

            foreach (object obj in this.repository.Values)
            {
                if (obj.GetType() == typeof(T))
                {
                    myList.Add( (T) obj);
                }
            }

            return myList;
        }

        public void Remove(Guid id)
        {
            this.repository.Remove(id);
        }
    }
}
