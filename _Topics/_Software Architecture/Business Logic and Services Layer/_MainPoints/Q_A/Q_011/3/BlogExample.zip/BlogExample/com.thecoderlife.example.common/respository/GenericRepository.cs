﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.thecoderlife.example.common.respository
{
    public abstract class GenericRepository<T>
    {
        public void Persist(Guid id, T obj)
        {
            //Real persistence load API calls could go here...
            ObjectRepository.GetInstance().Persist(id, obj);
        }

        public T Get(Guid id)
        {
            //and here...
            T obj = ObjectRepository.GetInstance().Get<T>(id);

            return obj;
        }

        public IList<T> GetAll()
        {
            //and so on...
            IList<T> myList = ObjectRepository.GetInstance().GetAllOf<T>();

            return myList;
        }
    }
}
