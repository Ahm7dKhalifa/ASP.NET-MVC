﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using com.thecoderlife.example.productcatalog.application;
using com.thecoderlife.example.productcatalog.repository;
using com.thecoderlife.example.productcatalog.model;

namespace com.thecoderlife.example.test
{
    [TestClass]
    public class CatalogServiceTest
    {
        private CatalogService service = new CatalogService();

        //helper method
        private string CreateAleatoryProduct(string title)
        {
            string inventoryCode = string.Format("INV-{0:0000}", DateTime.Now.Millisecond);

            string id = service.RegisterNewProduct(inventoryCode, title);

            return id;
        }

        /// <summary>
        /// Register a new product and gets the product ID
        /// </summary>
        [TestMethod]
        public void RegisterNewProduct_ReturnProductId_Test()
        {
            //assembly
            string title = "Test - This is a new product";

            //action
            string id = this.CreateAleatoryProduct(title);

            //assert
            Guid dummy;
            Assert.IsTrue( Guid.TryParse(id, out dummy));
        }

        /// <summary>
        /// Tries to register a new product without 'title' and gets an exception
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(Exception), "Invalid title! Please, provide a valid one.")]
        public void RegisterNewProduct_ExceptionDueMissingTitle_Test()
        {
            //assembly
            string title = null;

            //action
            string id = this.CreateAleatoryProduct(title);
        }

        /// <summary>
        /// Provides product details and checks if it was really updated
        /// </summary>
        [TestMethod]
        public void ProvideProductDetail_ProductUpdated_Test()
        {
            //assembly           
            string title = "Test - This is a detailed product";
            string description = "This is an updated description";
            string about = "This is an update about text";

            string id = this.CreateAleatoryProduct(title);

            //action
            this.service.ProvideProductDetail(id, description, about);           

            //assert
            ProductRepository repository = new ProductRepository();
            Guid productId = Guid.Parse(id);
            Product prod = repository.Get(productId);

            Assert.IsTrue(prod.GetDescription().Equals(description) &&
                          prod.GetAbout().Equals(about));
        }

        //Activates a product and checks the current Status
        [TestMethod]
        public void ActivateProduct_ProductActivated_Test()
        {
            //assembly
            string title = "Test - This is an activated product";
            string description = "This is a description";
            string about = "This is an about text";
            
            string id = this.CreateAleatoryProduct(title);

            //Provides details...
            this.service.ProvideProductDetail(id, description, about);
            
            //Provides dimension and weight...
            this.service.ProvideDimensionAndWeight(id, 10, 10, 10, "Inches", 1.2f, "Pounds");
            
            //Provides list price...
            this.service.ProvideProductListPrice(id, 22.50f);
            
            //Provides at least one picture...
            this.service.AddPicture(id, "images/image_0001.jpg");

            //action
            this.service.ActivateProduct(id);

            //assert
            ProductRepository repository = new ProductRepository();
            Guid productId = Guid.Parse(id);
            Product prod = repository.Get(productId);

            Assert.IsTrue(prod.GetStatus().Equals(ProductStatus.Active));
        }

        //Tries to activate a product without 'list price' and gets an exception
        [TestMethod]
        [ExpectedException(typeof(Exception), "Product cannot be activated! Please, make sure to provide the 'list price' for this product")]
        public void ActivateProduct_ExceptionDueListPriceMissing_Test()
        {
            //assembly
            string title = "Test - This is an activation try";
            string description = "This is a description";
            string about = "This is an about text";

            string id = this.CreateAleatoryProduct(title);

            //Provides details...
            this.service.ProvideProductDetail(id, description, about);

            //Provides dimension and weight...
            this.service.ProvideDimensionAndWeight(id, 10, 10, 10, "Inches", 1.2f, "Pounds");

            //Provides at least one picture...
            this.service.AddPicture(id, "images/image_0001.jpg");

            //action
            this.service.ActivateProduct(id);

            //assert
        }
    }
}
