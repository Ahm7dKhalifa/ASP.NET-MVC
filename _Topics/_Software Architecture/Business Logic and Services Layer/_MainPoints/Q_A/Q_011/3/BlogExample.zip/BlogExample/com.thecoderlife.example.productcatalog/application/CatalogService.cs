﻿using com.thecoderlife.example.common.respository;
using com.thecoderlife.example.productcatalog.dto;
using com.thecoderlife.example.productcatalog.model;
using com.thecoderlife.example.productcatalog.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.thecoderlife.example.productcatalog.application
{
    //Represents a "Catalog" Business Service
    public class CatalogService
    {
        /// <summary>
        /// Register a new product and returns the generated Id
        /// </summary>
        /// <param name="inventoryCode">The inventory code</param>
        /// <param name="title">Product name / title</param>
        /// <returns>String GUID</returns>
        public string RegisterNewProduct(string inventoryCode, string title)
        {
            Guid id = Guid.NewGuid();
            Product product = new Product(id, inventoryCode, title);

            ProductRepository rep = new ProductRepository();
            rep.Persist(id, product);

            return id.ToString();
        }

        /// <summary>
        /// Provides product's details
        /// </summary>
        /// <param name="productId">Product's id</param>
        /// <param name="description">Product's description</param>
        /// <param name="about">Product's about</param>
        public void ProvideProductDetail(string productId, string description, string about)
        {
            Guid id = Guid.Parse(productId);

            ProductRepository rep = new ProductRepository();
            Product product = rep.Get(id);

            product.SetAbout(about);
            product.SetDescription(description);

            rep.Persist(id, product);
        }

        /// <summary>
        /// Adds a picture to the product
        /// </summary>
        /// <param name="productId">Product's id</param>
        /// <param name="filePath">File path to the picture</param>
        public void AddPicture(string productId, string filePath)
        {
            Guid id = Guid.Parse(productId);

            ProductRepository rep = new ProductRepository();
            Product product = rep.Get(id);
            
            product.AddPicture(filePath);

            rep.Persist(id, product);
        }

        /// <summary>
        /// Provides information about dimension and weight
        /// </summary>
        /// <param name="dUnit">Unit of measure for "Dimension"</param>
        /// <param name="wUnit">Unit of measure for "Weight"</param>
        public void ProvideDimensionAndWeight(string productId, float lenght, float height, float depth, string dUnit, float weight, string wUnit)
        {
            Guid id = Guid.Parse(productId);

            ProductRepository rep = new ProductRepository();
            Product product = rep.Get(id);

            DimensionUnit dimensionUnit = (DimensionUnit) Enum.Parse(typeof(DimensionUnit), dUnit);
            WeightUnit weightUnit = (WeightUnit)Enum.Parse(typeof(WeightUnit), wUnit);

            Dimension dimensionObj = new Dimension(lenght, height, depth, dimensionUnit);
            Weight weightObj = new Weight(weight, weightUnit);

            product.SetDimension(dimensionObj);
            product.SetWeight(weightObj);

            rep.Persist(id, product);
        }

        /// <summary>
        /// Provides the list price information 
        /// </summary>        
        public void ProvideProductListPrice(string productId, float price)
        {
            Guid id = Guid.Parse(productId);

            ProductRepository rep = new ProductRepository();
            Product product = rep.Get(id);

            product.ChangeListPrice(price);

            rep.Persist(id, product);
        }

        /// <summary>
        /// Activate a product (make it avaiable in the catalog)
        /// </summary>
        public void ActivateProduct(string productId)
        {
            Guid id = Guid.Parse(productId);

            ProductRepository rep = new ProductRepository();
            Product product = rep.Get(id);

            product.Activate();

            rep.Persist(id, product);
        }

        /// <summary>
        /// Returns a list of CatalogItems (products which are active)
        /// </summary>
        /// <returns>IList CatalogItem</returns>
        public IList<CatalogItem> GetCatalogItems()
        {
            ProductRepository rep = new ProductRepository();

            IList<CatalogItem> items = rep.GetCataloItems();

            return items;
        }
    }
}
