﻿using com.thecoderlife.example.common.respository;
using com.thecoderlife.example.productcatalog.dto;
using com.thecoderlife.example.productcatalog.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.thecoderlife.example.productcatalog.repository
{
    public class ProductRepository : GenericRepository<Product>
    {
        public IList<CatalogItem> GetCataloItems()
        {
            //In a real persistence scenario, data would not come from "Entity"
            //Avoid the overhead of Entities loading just for getting data!

            IList<Product> products = this.GetAll();
            IList<CatalogItem> items = new List<CatalogItem>();

            foreach (Product p in products)
            {
                if (p.GetStatus() == ProductStatus.Active)
                {
                    items.Add(
                        new CatalogItem
                        {
                            About = p.GetAbout(),
                            ListPrice = p.GetListPrice(),
                            MainPicture = p.GetPicture(0),
                            ProductId = p.GetId().ToString(),
                            Title = p.GetTitle()

                        });
                }
            }

            return items;
        }
    }
}
