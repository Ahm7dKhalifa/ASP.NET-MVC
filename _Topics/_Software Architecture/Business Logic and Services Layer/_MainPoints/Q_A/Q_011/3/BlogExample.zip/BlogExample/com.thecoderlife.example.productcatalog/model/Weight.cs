﻿using com.thecoderlife.example.common.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace com.thecoderlife.example.productcatalog.model
{
    public enum WeightUnit 
    {
        Pounds = 1,
        Kilograms,
        Grams
    }

    public class Weight : ValueObject
    {
        private float value;
        private WeightUnit unit;

        public Weight(float value, WeightUnit unit)
        {
            if (value <= 0)
                throw new Exception("Invalid value for weight! Please, provide a valid one.");

            this.value = value;
            this.unit = unit;
        }

        public float GetValue()
        {
            return this.value;
        }

        public WeightUnit GetUnit()
        {
            return this.unit;
        }
    }
}
