﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace com.thecoderlife.example.productcatalog.model
{
    public enum ProductStatus
    {
        Registered = 1,
        Active,
        Inactive,
        Removed
    }

    //Product abstraction
    public class Product
    {
        #region attributes

        private Guid id;
        private string inventoryCode;
        private string title;
        private string about;
        private string description;
        private float listPrice;
        private ProductStatus status;
        private DateTime registration;
        private IList<string> pictures;
        private Dimension dimension;
        private Weight weight;

        #endregion

        #region constructor

        public Product(Guid id, string inventoryCode, string title)
        {
            if (id == null)
                throw new Exception("Invalid Id!");

            if (string.IsNullOrWhiteSpace(inventoryCode))
                throw new Exception("Invalid Inventory Code!");

            this.id = id;
            this.inventoryCode = inventoryCode;

            this.ChangeTitle(title);

            this.registration = DateTime.Now;
            this.status = ProductStatus.Registered;

            this.pictures = new List<string>();
        }

        #endregion

        #region interface methods

        public Guid GetId()
        {
            return this.id;
        }

        public string GetInventoryCode()
        {
            return this.inventoryCode;
        }

        public string GetTitle()
        {
            return this.title;
        }

        public void ChangeTitle(string t)
        {
            if (string.IsNullOrWhiteSpace(t))
                throw new Exception("Invalid title! Please, provide a valid one.");

            this.title = t;
        }

        public string GetAbout()
        {
            return this.about;
        }

        public void SetAbout(string a)
        {
            this.about = a;
        }

        public string GetDescription()
        {
            return this.description;
        }

        public void SetDescription(string d)
        {
            if (!string.IsNullOrWhiteSpace(d) && d.Length > 300)
                throw new Exception("Description exceeds the maximum of 300 characters.");

            this.description = d;
        }

        public float GetListPrice()
        {
            return this.listPrice;
        }

        public void ChangeListPrice(float p)
        {
            if (p <= 0)
                throw new Exception("List price cannot be less or equal to 0 (zero).");

            this.listPrice = p;
        }

        public ProductStatus GetStatus()
        {
            return this.status;
        }

        public DateTime GetRegistrationDate()
        {
            return this.registration;
        }

        public int GetNumberOfPictures()
        {
            return this.pictures.Count;
        }

        public string GetPicture(int index)
        {
            return this.pictures[index];
        }

        public void AddPicture(string pic)
        {
            if (string.IsNullOrEmpty(pic))
                throw new Exception("Please... provide a valid path to the picture.");

            this.pictures.Add(pic);
        }

        public void RemovePicture(int index)
        {
            this.pictures.RemoveAt(index);
        }

        public void SetDimension(Dimension dimension)
        {
            if (dimension == null)
                throw new Exception("Invalid dimension object!");

            this.dimension = dimension;
        }

        public void SetWeight(Weight weight)
        {
            if (weight == null)
                throw new Exception("Invalid Weight object!");

            this.weight = weight;
        }

        public void Activate()
        {
            //guarantees the "machine state" logic
            if (this.status == ProductStatus.Registered || this.status == ProductStatus.Inactive)
            {
                //verifies if all the necessary data have been set. A product cannot be activated without Dimension, for example
                
                if (string.IsNullOrWhiteSpace(this.description) || string.IsNullOrWhiteSpace(this.about))
                    throw new Exception("Product cannot be activated! Please, make sure to provide product details like 'description' and 'about'");

                if (this.dimension == null || this.weight == null)
                    throw new Exception("Product cannot be activated! Please, make sure to provide product measures like 'dimension' and 'weight'");

                if (this.listPrice == 0)
                    throw new Exception("Product cannot be activated! Please, make sure to provide the 'list price' for this product");

                //and if everthing is ok... change the status!
                this.status = ProductStatus.Active;
            }
            else
                throw new Exception(string.Format("Cannot activate this product! Current status is '{0}'", this.status));
        }

        public void Deactivate()
        {
            //guarantees the "machine state" logic
            if (this.status == ProductStatus.Active)
                this.status = ProductStatus.Inactive;
            else
                throw new Exception(string.Format("Cannot deactivate this product! Current status is '{0}'", this.status));
        }

        #endregion
    }
}
