﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.thecoderlife.example.productcatalog.dto
{
    /// <summary>
    /// Represents product data in the catalog
    /// </summary>
    [Serializable]
    public class CatalogItem
    {
        #region Properties

        public string ProductId { get; set; }
        public string Title { get; set; }
        public float ListPrice { get; set; }
        public string About { get; set; }
        public string MainPicture { get; set; }

        #endregion
    }
}
