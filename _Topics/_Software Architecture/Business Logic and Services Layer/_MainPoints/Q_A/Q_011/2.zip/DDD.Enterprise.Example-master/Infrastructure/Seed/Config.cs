﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seed
{
    public static class Config
    {
        public static Int32 MAX_RECORDS = 200;
    }
}