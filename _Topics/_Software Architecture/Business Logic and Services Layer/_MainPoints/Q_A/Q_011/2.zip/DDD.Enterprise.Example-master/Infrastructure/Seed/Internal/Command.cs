﻿namespace Seed.Internal
{
    public class Command
    {
    }
}