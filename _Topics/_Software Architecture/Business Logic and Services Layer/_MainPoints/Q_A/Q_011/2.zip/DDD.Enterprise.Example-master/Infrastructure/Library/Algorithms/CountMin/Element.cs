﻿namespace Demo.Library.Algorithms.CountMin
{
    public class Element
    {
        public byte[] Data { get; set; }
        public ulong Freq { get; set; }
    }
}
