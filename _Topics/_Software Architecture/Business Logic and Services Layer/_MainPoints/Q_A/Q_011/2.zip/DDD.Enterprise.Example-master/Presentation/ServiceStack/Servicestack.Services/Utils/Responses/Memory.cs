﻿namespace Demo.Presentation.ServiceStack.Utils.Responses
{
    public class Memory
    {
        public float FreeBytes { get; set; }

        public float ProcessBytes { get; set; }

    }
}
