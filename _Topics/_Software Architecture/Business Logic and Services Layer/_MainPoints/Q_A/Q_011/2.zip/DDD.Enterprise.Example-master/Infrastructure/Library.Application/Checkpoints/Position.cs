﻿namespace Demo.Library.Checkpoints
{
    public class Checkpoint
    {
        public string Id { get; set; }
        public long Position { get; set; }
    }
}