﻿using System.Reflection;

[assembly: AssemblyProduct("Demo.Presentation.ServiceStack")]
[assembly: AssemblyDescription("Demo Application Servicestack")]
[assembly: AssemblyCopyright("Copyright © Charles Solar 2016")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]