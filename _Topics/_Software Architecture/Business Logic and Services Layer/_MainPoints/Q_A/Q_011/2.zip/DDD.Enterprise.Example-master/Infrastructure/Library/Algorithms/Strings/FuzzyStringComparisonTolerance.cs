﻿namespace Demo.Library.Algorithms.Strings
{
    public enum FuzzyStringComparisonTolerance
    {
        Strong,

        Normal,

        Weak,

        Manual
    }
}
