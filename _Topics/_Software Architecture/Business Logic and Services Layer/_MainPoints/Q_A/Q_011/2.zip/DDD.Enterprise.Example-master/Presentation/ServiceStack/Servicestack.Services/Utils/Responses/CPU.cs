﻿namespace Demo.Presentation.ServiceStack.Utils.Responses
{
    public class Cpu 
    {
        public float TotalUsage { get; set; }
        public float ProcessUsage { get; set; }
    }
}
