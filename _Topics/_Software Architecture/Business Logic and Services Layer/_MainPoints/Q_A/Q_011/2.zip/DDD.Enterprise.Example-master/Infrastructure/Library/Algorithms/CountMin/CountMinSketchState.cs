﻿namespace Demo.Library.Algorithms.CountMin
{
    public class CountMinSketchState
    {
        public double Epsilon;
        public double Delta;
        public ulong Count;
        public ulong[][] Matrix;
    }
}
