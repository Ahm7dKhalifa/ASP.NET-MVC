﻿using Demo.Library.Command;

namespace Demo.Domain.Infrastructure.Demo
{
    public interface ReduceMetrics : IDemoEvent
    {
    }
}
