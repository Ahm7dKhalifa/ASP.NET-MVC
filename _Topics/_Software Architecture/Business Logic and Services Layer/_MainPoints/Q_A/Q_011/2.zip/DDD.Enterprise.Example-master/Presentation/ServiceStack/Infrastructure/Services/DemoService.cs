﻿using ServiceStack;

namespace Demo.Presentation.ServiceStack.Infrastructure.Services
{
    public class DemoService : Service
    {
    }
}