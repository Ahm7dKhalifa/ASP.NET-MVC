﻿namespace Demo.Library.Extensions
{
    public static class NumberExtensions
    {
        
    }
}
