﻿using System.Reflection;

[assembly: AssemblyProduct("Demo.Domain")]
[assembly: AssemblyDescription("Demo Domain")]
[assembly: AssemblyCopyright("Copyright © Charles Solar 2016")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]