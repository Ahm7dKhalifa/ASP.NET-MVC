﻿using NServiceBus;

namespace Demo.Library.Queries
{
    public interface IQuery : IMessage
    {
    }
}
